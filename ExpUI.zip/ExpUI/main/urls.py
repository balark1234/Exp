from django.urls import path
from . import views

urlpatterns = [
path("",views.Index, name = 'home'),                                                     # Home page
path("About",views.About, name = 'About'),                                              # About
path("Signup",views.SignUpView, name = 'signup'),                                       # About
path("expenses/",views.Expensesform, name='Expense_insert'),                             # Add Expenses
path("expenses/<int:pk>",views.Expensesform, name='expense_update'),                     # Update Expenses
path("delete/<int:pk>",views.Expense_delete, name='expense_delete'),                     # Delete Expense record
path("expenses/List",views.Expenses_List, name='expense_list'),                          # Expenses List
path("income/",views.Incomeform, name='Income_insert'),                                  # Add Income
path("<int:pk>",views.Income_List, name='income_update'),                                # Update Income
path("income/List",views.Income_List, name='income_List'),                               # Income List
path("delete/<int:pk>",views.Income_delete, name='Income_delete'),                       # Delete Income record
path("summaryList",views.SummaryList, name='SummaryList'),                              # Summary List
path('ajax/load_Type_Name/', views.load_Type_Name, name='ajax_load_Type_Name'),          # AJAX
]