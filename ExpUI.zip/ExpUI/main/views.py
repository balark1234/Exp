from django.forms import forms
from django.http import JsonResponse
from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from .forms import *
from .models import *

# Create your views here.

def Expensesform(request,pk=0):
	if request.method == "GET":
		if pk == 0:
			form = Expense_Form()
		else:
			ExpUp = Expenses.objects.get(pk=pk)
			form = Expense_Form(instance=ExpUp)
		return render(request,"main/Expenses.html",{'form':form})
	else:
		if pk == 0:
			print(request.POST)
			form = Expense_Form(request.POST)
		else:
			ExpUp = Expenses.objects.get(pk=pk)	
			form = Expense_Form(request.POST,instance=ExpUp)
		if form.is_valid():
			form.save()
		else:
			print(form.errors)
		return redirect('/expenses')

# AJAX
def load_Type_Name(request):	
	Exp_Ty_name = request.GET.get('exp_type_name')
	Exp_nam = ExpenseName.objects.filter(exp_type_name=Exp_Ty_name)
	print(Exp_nam)
	return render(request,'main/Exp_DropDown_List.html',{'Exp_nam':Exp_nam})
	#return JsonResponse(list(Exp_nam.values('n_s_no', 'name')), safe=False)

def Expenses_List(request):
	expenses_List = Expenses.objects.order_by('-transaction_date')
	context = {
		'expenses_List': expenses_List
	}
	return render(request,"main/ExpensesList.html",context)

def Expense_delete(request,pk):
	ExpDel = Expenses.objects.get(pk=pk)	
	ExpDel.delete()
	return redirect('/expenses/List')

def Incomeform(request):
	if request.method == "GET":
		form = Income_from()
		return render(request,"main/Income.html", {'form':form})
	else:
		form = Income_from(request.POST)
		if form.is_valid():
			form.save()
		return redirect('/income')

def Income_List(request):
	Inc_List = Income.objects.order_by('-received_date')
	context = {
		'Inc_List' : Inc_List
	}
	return render(request,"main/IncomeList.html",context)

def Income_delete(request):
	return render(request,"main/Income.html")

def SummaryList(request):
	S_List = Summary.objects.all()
	context = {
		'S_List' : S_List
	}
	return render(request,"main/SummaryList.html", context)

def Index(request):
	return render(request,"main/home.html")

def About(request):
	return render(request,"main/about.html")

def SignUpView(request):
	if request.method == "GET":
		fm = SignUpform()
		return render(request,"main/signup.html", {'form':fm})
	else:
		fm = User.objects.create_user(request.POST)
		#if fm.is_valid():
		fm.save()
		return redirect('/Signup/')