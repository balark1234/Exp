# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class DebugTable(models.Model):
    d_s_no = models.AutoField(db_column='D_S_No', primary_key=True)  # Field name made lowercase.
    added_dt = models.DateTimeField(db_column='Added_DT')  # Field name made lowercase.
    remarks = models.CharField(db_column='Remarks', max_length=200, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'debug_table'


class ExpenseName(models.Model):
    n_s_no = models.AutoField(db_column='N_S_No', primary_key=True)  # Field name made lowercase.
    exp_type_name = models.ForeignKey('ExpenseType', models.DO_NOTHING, db_column='Exp_Type_Name', to_field = 'type_name')  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=200,unique=True)  # Field name made lowercase.
    exp_dt = models.DateTimeField(db_column='Exp_DT')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'expense_name'
    def __str__(self):
        return self.name


class ExpenseType(models.Model):
    type_s_no = models.AutoField(db_column='Type_S_No', primary_key=True)  # Field name made lowercase.
    type_name = models.CharField(db_column='Type_Name', max_length=200, unique=True)  # Field name made lowercase.
    type_created_dt = models.DateTimeField(db_column='Type_Created_DT', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'expense_type'
    def __str__(self):
        return self.type_name


class Expenses(models.Model):
    s_no = models.AutoField(db_column='S_No', primary_key=True)  # Field name made lowercase.
    transaction_date = models.DateTimeField(db_column='Transaction_DT')  # Field name made lowercase.
    type_of_expense = models.ForeignKey(ExpenseType, models.DO_NOTHING, db_column='Type_Of_Expense', to_field = 'type_name')  # Field name made lowercase.
    expense_name = models.ForeignKey(ExpenseName, models.DO_NOTHING, db_column='Expense_Name', to_field = 'name')  # Field name made lowercase.
    expense_amount = models.DecimalField(max_digits=25, decimal_places=5, db_column='Expense_Amount')  # Field name made lowercase.
    remarks = models.CharField(db_column='Remarks', max_length=200, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'expenses'
    def __str__(self): 
        return self.expense_name

class IncomeSources(models.Model):
    in_s_no = models.AutoField(db_column='IN_S_No', primary_key=True)  # Field name made lowercase.
    income_source_name = models.CharField(db_column='Income_Source_Name', max_length=100,unique=True)  # Field name made lowercase.
    created_dt = models.DateTimeField(db_column='Created_DT')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'income_sources'
    def __str__(self): 
        return self.income_source_name

class Income(models.Model):
    income_s_no = models.AutoField(db_column='Income_S_No', primary_key=True)  # Field name made lowercase.
    income_source = models.ForeignKey(IncomeSources, models.DO_NOTHING, db_column='Income_source', to_field = 'income_source_name')  # Field name made lowercase.
    amount = models.FloatField(db_column='Amount')  # Field name made lowercase.
    received_for = models.CharField(db_column='Received_For', max_length=45)  # Field name made lowercase.
    received_date = models.DateTimeField(db_column='Received_Date')  # Field name made lowercase.
    remarks = models.CharField(db_column='Remarks', max_length=200, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'income'


class Summary(models.Model):
    smy_s_no = models.AutoField(db_column='Smy_S_No', primary_key=True)  # Field name made lowercase.
    expense_month = models.CharField(db_column='Expense_Month', unique=True, max_length=45)  # Field name made lowercase.
    monthly_total_exp = models.FloatField(db_column='Monthly_Total_Exp')  # Field name made lowercase.
    monthly_income = models.FloatField(db_column='Monthly_income')  # Field name made lowercase.
    balance = models.FloatField(db_column='Balance')  # Field name made lowercase.
    calculated_on = models.DateTimeField(db_column='Calculated_On')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'summary'
