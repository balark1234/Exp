from dataclasses import fields
from django import forms
from .models import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class DateTimeInput(forms.DateTimeInput):
    input_type = "date"

class Expense_Form(forms.ModelForm):
    class Meta:
        model= Expenses
        fields='__all__'
        #fields={transaction_date,type_of_expense,expense_name,expense_amount,remarks}
        widgets = {
            'transaction_date' : DateTimeInput()
        }
        labels={
            'transaction_date'          :      'Exp Date',
            'type_of_expense'           :      'Exp Type',
            'expense_name'              :      'Name',
            'expense_amount'            :      'Amount'
        }

    def __init__(self,*args,**kwargs):
        super(Expense_Form, self).__init__(*args,**kwargs)
        self.fields['type_of_expense'].empty_label = 'Select'
        self.fields['expense_name'].empty_label = 'Select'
        self.fields['remarks'].required = False
        self.fields['expense_name'].queryset = ExpenseName.objects.all()
        # print('#########################################################')
        # print(self.data)     
        # if 'expense_name' in self.data:
        #     try:
        #         Ex_id = int(self.data.get('expense_name'))
        #         print('!!!!!!!!!!!!!!!!!!!!!!!!------------Ex_id')                
        #         print(Ex_id)
        #         self.fields['expense_name'].queryset = ExpenseName.objects.filter(n_s_no=Ex_id).all()
        #         print(self.fields['expense_name'].queryset)
        #     except (ValueError, TypeError):
        #         pass  # invalid input from the client; ignore and fallback to empty City queryset
        #  elif self.instance.pk:
        #     self.fields['expense_name'].queryset = ExpenseName.objects.filter(n_s_no=pk).all()

class Income_from(forms.ModelForm):
    class Meta:
        model= Income
        fields='__all__'
        widgets = {
            'received_date' : DateTimeInput()
        }
        labels={
            'income_source' : 'Source',
            'received_for'  : 'Month',
            'received_date' : 'Received Date',
        }

    def __init__(self,*args,**kwargs):
        super(Income_from, self).__init__(*args,**kwargs)
        self.fields['income_source'].empty_label = '---       -- Select --       ---'
        self.fields['remarks'].required = False
        
            

class SignUpform(UserCreationForm):
    class Meta:
        model = User
        #fields='__all__'
        fields={'username','first_name','last_name','email','password1','password2'}