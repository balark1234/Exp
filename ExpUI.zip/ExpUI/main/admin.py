from django.contrib import admin
from .models import Expenses
# Register your models here.

class ExpList(admin.ModelAdmin):
    list_display = ['transaction_date','type_of_expense','expense_name','expense_amount','remarks']

admin.site.register(Expenses,ExpList)